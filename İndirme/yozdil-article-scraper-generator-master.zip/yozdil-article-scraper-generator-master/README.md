# Yılmaz Özdil Article Scraper and Generator
Scrape Yılmaz Özdil articles from Sözcü and Hürriyet newspapers (2007 to 2019) and create Markov model to generate newspaper articles like Yılmaz Özdil. Turkish text dataset creator for data science and NLP projects.

> **markoscrape** = (Markov + Scrape)

**For educational purposes only.**
